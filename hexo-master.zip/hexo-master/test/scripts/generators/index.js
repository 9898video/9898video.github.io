'use strict';

describe('Generators', () => {
  require('./asset');
  require('./page');
  require('./post');
});
