'use strict';

describe('Tags', () => {
  require('./asset_img');
  require('./asset_link');
  require('./asset_path');
  require('./blockquote');
  require('./code');
  require('./iframe');
  require('./img');
  require('./include_code');
  require('./link');
  require('./post_link');
  require('./post_path');
  require('./pullquote');
});
